export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBWJfrbXTqgEzoacqhOx5OXKJkpghtkVCM",
  authDomain: "dmf-app-9e3f1.firebaseapp.com",
  databaseURL: "https://dmf-app-9e3f1-default-rtdb.firebaseio.com",
  projectId: "dmf-app-9e3f1",
  storageBucket: "dmf-app-9e3f1.appspot.com",
  messagingSenderId: "338188807500",
  appId: "1:338188807500:web:07ec21a8c2342ea95733e9",
  measurementId: "G-2QSN6KK9ER"
  },
};
