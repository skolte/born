export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBWJfrbXTqgEzoacqhOx5OXKJkpghtkVCM",
  authDomain: "dmf-app-9e3f1.firebaseapp.com",
  databaseURL: "https://dmf-app-9e3f1-default-rtdb.firebaseio.com",
  projectId: "dmf-app-9e3f1",
  storageBucket: "dmf-app-9e3f1.appspot.com",
  messagingSenderId: "338188807500",
  appId: "1:338188807500:web:07ec21a8c2342ea95733e9",
  measurementId: "G-2QSN6KK9ER"
  },
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
